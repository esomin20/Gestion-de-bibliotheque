from tkinter import *
from utilisateur_page import *



def util_connection():
    window = Toplevel()
    window.title("connection utilisateur")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")

    def se_connecter():
        identifiant = user.get()
        mot_de_passe = code.get()
        if (identifiant == 'client' and mot_de_passe==mot_de_passe):
            util_page()
        elif identifiant == '' or mot_de_passe == '':
            messagebox.showerror(" veuillez entrer le mot de passe et l'identifiant")
        else:
            messagebox.showerror('mot de passe ou identifiant incorrectes')

    img = PhotoImage(file='sidentifier.png')
    Label(window, image=img, bg='#E5F4FF').place(x=45, y=50)
    frame = Frame(window, width=350, height=350, bg="#E5F4FF")
    frame.place(x=600, y=70)
    heading = Label(frame, text='Utilisateur', fg='#0693F8', bg='#E5F4FF',
                    font=('Microsoft Yahei UI Light', 23, 'bold'))
    heading.place(x=100, y=50)

    # ....................................................................................................................................
    def on_enter(e):
        user.delete(0, 'end')

    def on_leave(e):
        id = user.get()
        if id == '':
            user.insert(0, 'identifiant')

    user = Entry(frame, width=25, fg='black', border=0, bg="#E5F4FF", font=('Microsoft Yahei UI Light', 11))
    user.place(x=30, y=90)
    user.insert(0, 'identifiant')
    user.bind('<FocusIn>', on_enter)
    user.bind('<FocusOut>', on_leave)
    Frame(frame, width=295, height=2, bg='black').place(x=25, y=117)

    # ....................................................................................................................................
    def on_enter(e):
        code.delete(0, 'end')

    def on_leave(e):
        id = code.get()
        if id == '':
            code.insert(0, 'mot de passe')

    code = Entry(frame, width=25, fg='black', border=0, bg="#E5F4FF", font=('Microsoft Yahei UI Light', 11))
    code.place(x=30, y=160)
    code.insert(0, ' mot de passe')
    code.bind('<FocusIn>', on_enter)
    code.bind('<FocusOut>', on_leave)
    Frame(frame, width=295, height=2, bg='black').place(x=25, y=187)
    # ....................................................................................................................................
    Button(frame, width=39, pady=7, text='connection', bg='#0693F8', fg='white', border=0, command=se_connecter).place(
        x=35, y=204)

    window.mainloop()
