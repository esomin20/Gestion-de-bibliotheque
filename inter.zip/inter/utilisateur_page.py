from tkinter import *
from tkinter import messagebox
from affichge import *
def util_page():
    window = Toplevel()
    window.title("page utilisateur")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    frame = Frame(window, bg='#E5F4FF')
    width = 500
    height = 500
    image = PhotoImage(file="bibliotheque-numerique.png").zoom(20).subsample(32)
    canvas = Canvas(frame, width=width, height=height, bg='#E5F4FF', bd=0, highlightthickness=0)
    canvas.create_image(width / 2, height / 2, image=image)
    canvas.pack(side=BOTTOM)
    label_title = Label(frame, text=" Binvenue cher client ", font=("script", 40, 'bold'), bg='#E5F4FF',
                        fg='#0693F8')

    label_title.pack()
    frame.pack()
    # ajout des bouttons
    emp_button = Button(frame, width=33, pady=30, text="livres à emprunter", bg='#0693F8', fg='white', border=0,command=emprunter )
    emp_button.pack(side=LEFT)
    display_button = Button(frame, width=33, pady=30, text='afficher tous les livres', bg='#0693F8', fg='white', border=0,command=affiche_livres )
    display_button.pack(side=LEFT)
    cheep_button = Button(frame, width=33, pady=30, text='les moins chers', bg='#0693F8', fg='white', border=0, command=cheep)
    cheep_button.pack(side=LEFT)
    exp_button = Button(frame, width=33, pady=30, text='les plus chers', bg='#0693F8', fg='white', border=0,command=exp)
    exp_button.pack(side=LEFT)
    medium_button = Button(frame, width=33, pady=30, text='à 100dh seulement', bg='#0693F8', fg='white', border=0,command=dh)
    medium_button.pack(side=LEFT)
    time_button = Button(frame, width=33, pady=30, text='les derniers livres', bg='#0693F8', fg='white', border=0,command=time)
    time_button.pack(side=LEFT)
    # afficher
    window.mainloop()