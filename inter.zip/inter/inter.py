from tkinter import *
from administrateur_connection import *
from utilisateur_connection import *
from sans_connection import *
#creation de fenetre et personalisation
window=Tk()
window.title("biblio")
window.geometry("720x480")
window.minsize(480,360)
window.iconbitmap("logo.ico")
window.config(background='#E5F4FF')
frame=Frame(window,bg='#E5F4FF')
width = 300
height =300
image = PhotoImage(file="etagere-a-livres.png").zoom(20).subsample(32)
canvas = Canvas(frame, width=width, height=height, bg='#E5F4FF', bd=0, highlightthickness=0)
canvas.create_image(width / 2, height / 2, image=image)
canvas.pack()
label_title=Label(frame,text=" Bienvenue à notre bibliotheque ",font=("Helevetica",40),bg='#E5F4FF',fg='#0693F8')
label_title.pack()
label_subtitle=Label(frame,text=" “La lecture est à l'esprit ce que l'exercice est au corps.” ",font=("Helevetica",25),bg='#E5F4FF',fg='#0693F8')
label_subtitle.pack()
frame.pack(expand=YES)
#ajout des bouttons
adm_button=Button(frame,text=" se connecter comme administrateur",font=("courrier",15),bg='#0693F8',fg='white',command=adm_connection)
adm_button.pack(pady=15,fill=X)
util_button=Button(frame,text=" se connecter comme utilisateur",font=("courrier",15),bg='#0693F8',fg='white', command=util_connection)
util_button.pack(pady=15,fill=X)
ss_button=Button(frame,text=" continuer sans connection",font=("courrier",15),bg='#0693F8',fg='white',command=sans_connection)
ss_button.pack(pady=15,fill=X)
#afficher
window.mainloop()