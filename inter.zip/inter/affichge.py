import mysql.connector
from tkinter import messagebox
from tkinter import *
def affiche_livres():
    window = Toplevel()
    window.title("nos livres")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM livre")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=22, fg='#0693F8' , bg='#E5F4FF' , border=0)
            e.grid(row=i, column=j , padx=0 ,pady=10)
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=30, text='Nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid( row=0, column=0, padx=0 ,pady=10)
        e = Label(window, width=30, text='ISBN', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0 ,pady=10)
        e = Label(window, width=30, text='nombre de pages', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0 ,pady=10)
        e = Label(window, width=30, text='prix de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='genre de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='état', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()
def emprunter():
    window = Toplevel()
    window.title("livre à emprunter")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )
    c = my_connect.cursor()
    c.execute("SELECT nom_livre FROM livre where etat='disponible'")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=30, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10,)
            e.insert(END, livre[j])
        i = i+1
        e = Label(window, width=100, text='livres disponibles', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
    window.mainloop()
def cheep():
    window = Toplevel()
    window.title("prix raisonnables")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )
    c = my_connect.cursor()
    c.execute("SELECT nom_livre as 'NOM DE LIVRE' , prix_livre AS 'PRIX EN DH' FROM livre WHERE prix_livre<100")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=30, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10, )
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=100, text='livres moins chers', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=100, text='prix', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
    window.mainloop()
def exp():
    window = Toplevel()
    window.title("prix chers")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )
    c = my_connect.cursor()
    c.execute(" SELECT nom_livre as 'NOM DE LIVRE' , prix_livre AS 'PRIX EN DH' FROM livre WHERE prix_livre>100")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=30, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10, )
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=100, text='les plus chers', borderwidth=2, relief='ridge', anchor='w',bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=100, text='prix', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
    window.mainloop()

def dh():
    window = Toplevel()
    window.title("100 dh")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )
    c = my_connect.cursor()
    c.execute("SELECT nom_livre as 'NOM DE LIVRE' , prix_livre AS 'PRIX EN DH' FROM livre WHERE prix_livre=100 ")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=30, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10, )
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=100, text='à 100 dh', borderwidth=2, relief='ridge', anchor='w',bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=100, text='prix', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
    window.mainloop()
def time():
    window = Toplevel()
    window.title("les derniers documents")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )
    c = my_connect.cursor()
    c.execute("SELECT titre_doc AS 'TITRE DE DOCUMENT' FROM document where annee_pub between 2012 AND 2022 ")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=30, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10, )
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=100, text='les derniers documents', borderwidth=2, relief='ridge', anchor='w',bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
    window.mainloop()
def affiche_livres_prix():
    window = Toplevel()
    window.title("nos livres")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM livre order by prix_livre")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=22, fg='#0693F8' , bg='#E5F4FF' , border=0)
            e.grid(row=i, column=j , padx=0 ,pady=10)
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=30, text='Nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid( row=0, column=0, padx=0 ,pady=10)
        e = Label(window, width=30, text='ISBN', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0 ,pady=10)
        e = Label(window, width=30, text='nombre de pages', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0 ,pady=10)
        e = Label(window, width=30, text='prix de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='genre de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='état', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()
def abonne():
    window = Toplevel()
    window.title("nos livres")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM utilisateur")
    i = 1
    for utilisateur in c:
        for j in range(len(utilisateur)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, utilisateur[j])
        i = i + 1
        e = Label(window, width=52, text='Id', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text='nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=52, text='prenom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=52, text='email', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
    window.mainloop()
def bibliothecaire():
    window = Toplevel()
    window.title("les bibliothecaires")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM bibliothecaire")
    i = 1
    for bibliothecaire in c:
        for j in range(len(bibliothecaire)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, bibliothecaire[j])
        i = i + 1
        e = Label(window, width=30, text='ID', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text='nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=30, text='prenom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=30, text='email', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='ville', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='code bibliotheque', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()
def stg():
    window = Toplevel()
    window.title("les stagiaires")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM stagiaire")
    i = 1
    for stagiaire in c:
        for j in range(len(stagiaire)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, stagiaire[j])
        i = i + 1
        e = Label(window, width=30, text='ID', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text='nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=30, text='prenom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=30, text='ville', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='email', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='code bibliotheque', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()
def der():
    window = Toplevel()
    window.title("document & exemplaires & rayons")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("select titre_doc as'TITRE DE DOCUMENT' , nom_edit AS 'NOM DE L EDITEUR' , libelle_rayon as 'NOM DU RAYON'from document , editeur , rayon where (editeur.code_edit=document.code_edit) and (rayon.num_rayon=document.num_rayon)")
    i = 1
    for document in c:
        for j in range(len(document)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, document[j])
        i = i + 1
        e = Label(window, width=50, text='titre document', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=50, text="nom de l'editeur", borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=50, text='nom du rayon', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
    window.mainloop()
def ed():
    window = Toplevel()
    window.title("exemplaires et documents")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute(
        "SELECT date_achat as 'DATE ACHAT', titre_doc as 'TITRE ' , nbre_exemp as 'N° EXEMPLAIRE', num_ordre AS 'NUMERO D ORDRE'from exemplaire , document where exemplaire.id_doc=document.id_doc order by date_achat")
    i = 1
    for exemplaire in c:
        for j in range(len(exemplaire)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, exemplaire[j])
        i = i + 1
        e = Label(window, width=45, text="date d'achat", borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=45, text="titre", borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=45, text='nombre exemplaire', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=45, text="numero d'ordre", borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
    window.mainloop()
def liste_emp():
    window = Toplevel()
    window.title("exemplaires et documents")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("select * from emprunter")
    i = 1
    for emprunter in c:
        for j in range(len(emprunter)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, emprunter[j])
        i = i + 1
        e = Label(window, width=30, text="numero d'ordre", borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text="id utilisateur", borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=30, text="type d'abonnement", borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=30, text="date de debut d'emprunt", borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text="date de fin d'emprunt", borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
    window.mainloop()
def roman():
    window = Toplevel()
    window.title("les romans")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM livre where genre='roman'")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=30, text='Nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text='ISBN', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=30, text='nombre de pages', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=30, text='prix de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='genre de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='état', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()
def arabe():
    window = Toplevel()
    window.title("livres d'arabes")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM livre where genre='arabe'")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=30, text='Nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text='ISBN', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=30, text='nombre de pages', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=30, text='prix de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='genre de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='état', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()
def francais():
    window = Toplevel()
    window.title("livres de français")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM livre where genre='français'")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=30, text='Nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text='ISBN', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=30, text='nombre de pages', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=30, text='prix de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='genre de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='état', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()

def anglais():
    window = Toplevel()
    window.title("livres d'anglais")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM livre where genre='anglais'")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=30, text='Nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text='ISBN', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=30, text='nombre de pages', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=30, text='prix de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='genre de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='état', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()

def philo():
    window = Toplevel()
    window.title("livre de philosophie")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM livre where genre='philosophie'")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=30, text='Nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text='ISBN', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=30, text='nombre de pages', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=30, text='prix de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='genre de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='état', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()

def psy():
    window = Toplevel()
    window.title("livres de psychologie")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    my_connect = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="asmaechadli2001",
        database="biblio"
    )

    c = my_connect.cursor()
    ####### end of connection ####
    c.execute("SELECT * FROM livre where genre='psychologie'")
    i = 1
    for livre in c:
        for j in range(len(livre)):
            e = Entry(window, width=22, fg='#0693F8', bg='#E5F4FF', border=0)
            e.grid(row=i, column=j, padx=0, pady=10)
            e.insert(END, livre[j])
        i = i + 1
        e = Label(window, width=30, text='Nom', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=0, padx=0, pady=10)
        e = Label(window, width=30, text='ISBN', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=1, padx=0, pady=10)
        e = Label(window, width=30, text='nombre de pages', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=2, padx=0, pady=10)
        e = Label(window, width=30, text='prix de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=3, padx=0, pady=10)
        e = Label(window, width=30, text='genre de livre', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=4, padx=0, pady=10)
        e = Label(window, width=30, text='état', borderwidth=2, relief='ridge', anchor='w', bg='#0693F8')
        e.grid(row=0, column=5, padx=0, pady=10)
    window.mainloop()




