from tkinter import *
from tkinter import messagebox
from affichge import *
def sans_connection():
    window = Toplevel()
    window.title("page navigation")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    frame = Frame(window, bg='#E5F4FF')
    width = 500
    height = 500
    image = PhotoImage(file="bibliotheque-cloud.png").zoom(20).subsample(32)
    canvas = Canvas(frame, width=width, height=height, bg='#E5F4FF', bd=0, highlightthickness=0)
    canvas.create_image(width / 2, height / 2, image=image)
    canvas.pack(side=BOTTOM)
    label_title = Label(frame, text=" Binvenue dans le monde de la lecture ", font=("script", 40, 'bold'), bg='#E5F4FF',
                        fg='#0693F8')

    label_title.pack()
    frame.pack()
    # ajout des bouttons
    roman_button = Button(frame, width=39, pady=30, text="l'art des romans", bg='#0693F8', fg='white', border=0,command=roman )
    roman_button.pack(side=LEFT)
    psychologie_button = Button(frame, width=30, pady=30, text='psychologie', bg='#0693F8', fg='white', border=0,command=psy )
    psychologie_button.pack(side=LEFT)
    philosophie_button = Button(frame, width=30, pady=30, text='philosophie', bg='#0693F8', fg='white', border=0,command=philo )
    philosophie_button.pack(side=LEFT)
    arabe_button = Button(frame, width=30, pady=30, text='العربية', bg='#0693F8', fg='white', border=0,command=arabe )
    arabe_button.pack(side=LEFT)
    anglais_button = Button(frame, width=30, pady=30, text='all in english', bg='#0693F8', fg='white', border=0,command=anglais )
    anglais_button.pack(side=LEFT)
    francais_button = Button(frame, width=39, pady=30, text='votre gout en français', bg='#0693F8', fg='white', border=0,command=francais )
    francais_button.pack(side=LEFT)
    # afficher
    window.mainloop()
