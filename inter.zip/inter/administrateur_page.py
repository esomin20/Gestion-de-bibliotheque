from tkinter import *
from tkinter import messagebox
from affichge import *
def adm_page():
    window=Toplevel()
    window.title("page administrateur")
    window.geometry("720x480")
    window.minsize(480, 360)
    window.iconbitmap("logo.ico")
    window.config(background='#E5F4FF')
    window.iconbitmap("logo.ico")
    frame = Frame(window, bg='#E5F4FF')
    width = 500
    height =500
    image = PhotoImage(file="etagere-a-livres (1).png").zoom(20).subsample(32)
    canvas = Canvas(frame, width=width, height=height, bg='#E5F4FF', bd=0, highlightthickness=0)
    canvas.create_image(width / 2, height / 2, image=image)
    canvas.pack(side=BOTTOM)
    label_title = Label(frame, text=" Bienvenue ", font=("script", 40,'bold'), bg='#E5F4FF',
                        fg='#0693F8')

    label_title.pack()
    frame.pack()
    # ajout des bouttons
    affiche_button = Button(frame,width=50,pady=30,text='livres triés par prix',bg='#0693F8',fg='white',border=0,command=affiche_livres_prix)
    affiche_button.pack(side=LEFT)
    abonne_button = Button(frame, width=20, pady=30, text='vos clients abonnés', bg='#0693F8', fg='white', border=0,command=abonne )
    abonne_button.pack(side=LEFT)
    bib_button = Button(frame, width=20, pady=30, text='vos employés', bg='#0693F8', fg='white', border=0,command=bibliothecaire )
    bib_button.pack(side=LEFT)
    stg_button = Button(frame, width=20, pady=30, text='vos stagiaires', bg='#0693F8', fg='white', border=0,command=stg )
    stg_button.pack(side=LEFT)
    der_button = Button(frame, width=20, pady=30, text='documents & editeurs', bg='#0693F8', fg='white', border=0,command=der )
    der_button.pack(side=LEFT)
    ed_button = Button(frame, width=20, pady=30, text='exemplaire & docuemnt', bg='#0693F8', fg='white', border=0,command=ed)
    ed_button.pack(side=LEFT)
    ep_button = Button(frame, width=50, pady=30, text='liste des empruntés', bg='#0693F8', fg='white', border=0, command=liste_emp)
    ep_button.pack(side=LEFT)
    # afficher
    window.mainloop()
